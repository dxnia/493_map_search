'use strict';


// Initialize Firebase
var config = {
    apiKey: "AIzaSyDc0ygJS0wJMRhBtGI7iE_7nqVssNnWMpE",
    authDomain: "projectf-371d9.firebaseapp.com",
    databaseURL: "https://projectf-371d9.firebaseio.com",
    projectId: "projectf-371d9",
    storageBucket: "",
    messagingSenderId: "88915555052"
  };

firebase.initializeApp(config);

var ref = firebase.database().ref();
var default_email = "test@example.com";

var secret_key = 'a^O\xff\t\xb5t\xc4\x14=\xe0p\xab\x18.y\xd5\xf9@f\xf4F\xd4\xd0';
/* Controllers */

var Final_Controllers = angular.module('Final_Controllers', ["firebase"]);

var provider = new firebase.auth.FacebookAuthProvider();
provider.addScope('email');
provider.addScope('user_friends');


function get_user() {
  var user = firebase.auth().currentUser;
  if (!user) {
    return -1;
  }
  return user;
}

function get_uid() {
  var user = get_user();
  if (user == -1) {
    return -1;
  }
  return user.providerData[0].uid;
}

//url in the form "?id=oi23i14h3tog813ghaosdjfo"
function checkToRedirect(url){
  var uid = get_uid();
  if(uid == -1) {
    console.log("no one logged in")
    console.log(url);
    if(url){
      console.log("/#/" + url)
      var location = "/#/" + url;
      window.location = location;
    } else {
      console.log("/")
      window.location = "/";
    }
  }

}


Final_Controllers.controller('searchPage',[ '$scope', '$http', '$window', 'Places', 'LatLong', 'upcomingTripService', function($scope, $http, $window, Places, LatLong, upcomingTripService) {
  console.log("i got here");

  console.log("SHARED PROPERTY: " + upcomingTripService.getProperty()); 

  // $scope.upcomingTrips = [
  //   {
  //     title: 'South East Asia Travels',
  //     image: 'images/SEAtravelstrip.png',
  //     start_date: new Date('2018', '02', '18'),
  //     end_date: new Date('2018', '02', '29'),
  //   },
  //   {
  //     title: 'Off to Toronto',
  //     image: 'images/torontotrip.png',
  //     start_date: new Date('2018', '06', '03'),
  //     end_date: new Date('2018', '06', '15'),
  //   }
  // ];

  // $scope.completedTrips = [
  //   {
  //     title: 'Tokyo and Kyoto',
  //     image: 'images/japantrip.png',
  //     start_date: new Date('2017', '07', '02'),
  //     end_date: new Date('2017', '07', '11'),
  //   },
  //   {
  //     title: 'Heading to India!',
  //     image: 'images/udaipurtrip.png',
  //     start_date: new Date('2017', '02', '10'),
  //     end_date: new Date('2017', '02', '23'),
  //   },
  //   {
  //     title: 'Ski Trip!',
  //     image: 'images/skitrip.png',
  //     start_date: new Date('2016', '11', '22'),
  //     end_date: new Date('2016', '11', '27'),
  //   },
  //   {
  //     title: 'Visiting the Capital',
  //     image: 'images/dctrip.jpg',
  //     start_date: new Date('2016', '05', '16'),
  //     end_date: new Date('2016', '05', '18'),
  //   }
  // ];


  $scope.attractions = {}; 
  $scope.photos_with_locations = {}; 
  $scope.add = function(city) {
    console.log("Add Function Returns City: " + city);
    $scope.city = city; 

      // alert("add function works " + city);
      Places.getData(city).then(function(response){
        console.log("response: " + response); 
        $scope.latlongobj = response;
        $scope.lat = response.lat; 
        $scope.long = response.lng;

      
      console.log("Nearby search url: " + 'https://maps.googleapis.com/maps/api/place/nearbysearch/json?location='+$scope.lat+','+$scope.long+'&radius=5000&rankby=prominence&key=AIzaSyBsxawHW0CdThQYREPYasco9mJ9Ub3VXqk');
      $http({
          method: 'GET',
          dataType: 'jsonp', 
          url: 'https://maps.googleapis.com/maps/api/place/nearbysearch/json?location='+$scope.lat+','+$scope.long+'&radius=10000&type=museum&rankby=prominence&key=AIzaSyBsxawHW0CdThQYREPYasco9mJ9Ub3VXqk'
        }).then(function successCallback(response) {
          
          var obj = JSON.stringify(response); 
              $scope.attractions = response.data.results; 
              console.log($scope.attractions);

          })
        
      });
  };



  console.log("woohoo seeing my trips");

  $scope.viewAddTripForm = false;
  $scope.toggleModal = function() {
      $scope.viewAddTripForm = !$scope.viewAddTripForm;
  };

  $scope.submitNewTrip = function() {
    console.log("Adding new trip!");

    var new_trip = {
      title: 'New Trip!',
      image: 'images/dctrip.jpg',
      start_date: new Date('2018', '11', '22'),
      end_date: new Date('2018', '11', '27'),
    }

    console.log("SHARED PROPERTY: " + upcomingTripService.setProperty(new_trip)); 

    // Final_Controllers.service('upcomingTripService', function() { 



    $scope.upcomingTrips.push(new_trip);
    console.log ("New Trip Created!");

   };

   $scope.upcomingTrips = upcomingTripService.getProperty(); 
   console.log($scope.upcomingTrips); 

  $scope.completedTrips = upcomingTripService.getCompleted(); 

   // $scope.upcomingTripService.upcomingTrips = upcomingTripService.upcomingTrips;



}]);

// Final_Controllers.directive('ngEnter', function () {
//     return function (scope, element, attrs) {
//         element.bind("keydown keypress", function (event) {
//             if(event.which === 13) {
//                 scope.$apply(function (){
//                     scope.$eval(attrs.ngEnter);
//                 });
 
//                 event.preventDefault();
//             }
//         });
//     };

// }]);


Final_Controllers.factory('Places', function($http) {

  var descriptionData = "";

  return {
      getData: getData
    };

    function getData(city) {
      //storyInfo = newWords;
        // console.log(artistName);
          // $scope.loading = true;
          console.log('https://maps.googleapis.com/maps/api/place/autocomplete/json?input='+city+'&key='+'AIzaSyBsxawHW0CdThQYREPYasco9mJ9Ub3VXqk'); 
        return $http({
          method: 'GET',
          dataType: 'jsonp', 
          cache: false, 
          url: 'https://maps.googleapis.com/maps/api/geocode/json?address='+city+'&key=AIzaSyBsxawHW0CdThQYREPYasco9mJ9Ub3VXqk'

          // url: 'https://maps.googleapis.com/maps/api/place/autocomplete/json?input='+city+'&key='+'AIzaSyAk2w4o27LZQzZrSk7QKq-erTQEGqZnnZo'
        }).then(function successCallback(response) {
          console.log("success " + response.data); 
          var obj = JSON.stringify(response); 
            console.log("object: " + obj); 
          console.log("response object " + JSON.stringify(response.data.results[0].geometry.location)); 

          if(response.data != null){ 
            // descriptionData = response.data.predictions[0].description;
            // locationId = response.data.predictions[0].id; 
            // predictions = response.data.predictions; 
          } 
          else{ 
            descriptionData = "Sorry, no description found";
          }
          return response.data.results[0].geometry.location;
          })
    }
  
});

Final_Controllers.factory('LatLong', function($http) {

  var descriptionData = "";

  return {
      getData: getData
    };

    function getData(latlong) {
      //storyInfo = newWords;
        // console.log(artistName);
          // $scope.loading = true;
            console.log("PLACE URL " + 'https://maps.googleapis.com/maps/api/place/radarsearch/json?location='+latlong.lat+','+latlong.long+'&radius=5000&key=AIzaSyBsxawHW0CdThQYREPYasco9mJ9Ub3VXqk');
            console.log("should be longitude: " + latlong.long); 
        return $http({
          method: 'GET',
          dataType: 'jsonp', 
          url: 'https://maps.googleapis.com/maps/api/place/radarsearch/json?location='+latlong.lat+','+latlong.long+'&radius=5000&key=AIzaSyBsxawHW0CdThQYREPYasco9mJ9Ub3VXqk'
        }).then(function successCallback(response) {
          console.log("success " + response); 
          console.log("response object " + response.data); 
          var obj = JSON.stringify(response); 
              console.log("object: " + obj); 
          console.log("photo object " + JSON.stringify(response.data.results.photos)); 
          if(response.data != null){ 
            descriptionData = response.data[0].description;
          } 
          else{ 
            descriptionData = "Sorry, no description found";
          }
          return descriptionData;
          })

    }
  
});


Final_Controllers.service('upcomingTripService', function() { 

  var property = 'First'; 


  var upcomingTrips = [
    {
      title: 'South East Asia Travels',
      image: 'images/SEAtravelstrip.png',
      start_date: new Date('2018', '02', '18'),
      end_date: new Date('2018', '02', '29'),
    },
    {
      title: 'Off to Toronto',
      image: 'images/torontotrip.png',
      start_date: new Date('2018', '06', '03'),
      end_date: new Date('2018', '06', '15'),
    }
  ];

  var completedTrips = [
    {
      title: 'Tokyo and Kyoto',
      image: 'images/japantrip.png',
      start_date: new Date('2017', '07', '02'),
      end_date: new Date('2017', '07', '11'),
    },
    {
      title: 'Heading to India!',
      image: 'images/udaipurtrip.png',
      start_date: new Date('2017', '02', '10'),
      end_date: new Date('2017', '02', '23'),
    },
    {
      title: 'Ski Trip!',
      image: 'images/skitrip.png',
      start_date: new Date('2016', '11', '22'),
      end_date: new Date('2016', '11', '27'),
    },
    {
      title: 'Visiting the Capital',
      image: 'images/dctrip.jpg',
      start_date: new Date('2016', '05', '16'),
      end_date: new Date('2016', '05', '18'),
    }
  ];

  var result_completed = []; 
  angular.copy(completedTrips, result_completed); 

  var result_trips = [];
  angular.copy(upcomingTrips, result_trips);

  return { 
    getCompleted: getCompleted, 
    getProperty: getProperty, 
    setProperty: setProperty
  };
  // setProperty: function(value){ 
    //   property = value; 
    // }
    function setProperty(value){ 
      upcomingTrips.push(value);

      property = value; 
    }

  function getProperty (){ 
      return result_trips; 
    }
  function getCompleted (){ 
      return result_completed; 
    }



}); 

// Final_Controllers.controller('myTripsPage',[ '$scope', '$http', function($scope, $http) {
//   console.log("woohoo seeing my trips");

//   $scope.viewAddTripForm = false;
//   $scope.toggleModal = function() {
//       $scope.viewAddTripForm = !$scope.viewAddTripForm;
//   };

//   $scope.upcomingTrips = [
//     {
//       title: 'South East Asia Travels',
//       image: 'images/SEAtravelstrip.png',
//       start_date: new Date('2018', '02', '18'),
//       end_date: new Date('2018', '02', '29'),
//     },
//     {
//       title: 'Off to Toronto',
//       image: 'images/torontotrip.png',
//       start_date: new Date('2018', '06', '03'),
//       end_date: new Date('2018', '06', '15'),
//     }
//   ];

//   $scope.completedTrips = [
//     {
//       title: 'Tokyo and Kyoto',
//       image: 'images/japantrip.png',
//       start_date: new Date('2017', '07', '02'),
//       end_date: new Date('2017', '07', '11'),
//     },
//     {
//       title: 'Heading to India!',
//       image: 'images/udaipurtrip.png',
//       start_date: new Date('2017', '02', '10'),
//       end_date: new Date('2017', '02', '23'),
//     },
//     {
//       title: 'Ski Trip!',
//       image: 'images/skitrip.png',
//       start_date: new Date('2016', '11', '22'),
//       end_date: new Date('2016', '11', '27'),
//     },
//     {
//       title: 'Visiting the Capital',
//       image: 'images/dctrip.jpg',
//       start_date: new Date('2016', '05', '16'),
//       end_date: new Date('2016', '05', '18'),
//     }
//   ];

//   $scope.submitNewTrip = function() {
//     console.log("Adding new trip!");

//     var new_trip = {
//       title: 'New Trip!',
//       image: 'images/dctrip.jpg',
//       start_date: new Date('2018', '11', '22'),
//       end_date: new Date('2018', '11', '27'),
//     }

//     $scope.upcomingTrips.push(new_trip);
//     console.log ("New Trip Created!");

//    };

// }]);

// Final_Controllers.directive('ngEnter', function () {
//     return function (scope, element, attrs) {
//         element.bind("keydown keypress", function (event) {
//             if(event.which === 13) {
//                 scope.$apply(function (){
//                     scope.$eval(attrs.ngEnter);
//                 });
 
//                 event.preventDefault();
//             }
//         });
//     };
// });


// ARGO STUFF /////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////


// argoumichControllers.controller('LandingCtrl', ['$scope', '$http', '$login', '$location',
//   function($scope, $http, $login, $location) {

//     $scope.logout = function(){
//         firebase.auth().signOut().then(function() {
//           // Sign-out successful.
//           console.log("Successfully signed out");
//         }, function(error) {
//           // An error happened.
//           console.log("Error in signing out");
//         });
//     };

//     $scope.fb_login = function() {
//       $login.$fb_login();
//     }


//     //Auth observer that gets triggered whenever a user's login status changes (e.g. when they log in or log out).
//     //In all other places, I use the var user = firebase.auth().currentUser syntax, but here this won't work since
//     //I think there's a possibility that the user is still being intialized, which won't make the call work.
//     //So here, I have to use this observer method instead.
//     firebase.auth().onAuthStateChanged(function(user) {
//       if (user) {
//         // User is signed in.
//         $scope.$apply(function() {
//           $scope.loginStatus = true;
//           console.log("User is signed in");
//         });
//       } else {
//         // No user is signed in.
//         $scope.$apply(function() {
//           $scope.loginStatus = false;
//           console.log("Nobody is signed in");
//         });
//       }
//     });

//     $scope.title = 'Argo';
//   }
// ]);

// argoumichControllers.controller('EmailCtrl',
//   function ($scope) {
//     //Check to see if the user has a valid e-mail (i.e. that's not test@example.com).
//     ref.once("value", function(snapshot) {
//       checkToRedirect();
//       var uid = get_uid();

//       $scope.current_email = snapshot.val()["Users"][uid]["email"];
//       $scope.current_phonenum = snapshot.val()["Users"][uid]["phonenum"];

//       if (!$scope.current_email || ($scope.current_email === default_email)) {
//         $scope.hasEmail = false;
//       }
//       else {
//         $scope.hasEmail = true;
//         $scope.new_email = $scope.current_email
//       }

//       if ($scope.current_phonenum) {
//         $scope.hasPhone = true;
//         $scope.new_phonenum = $scope.current_phonenum
//       } else {
//         $scope.hasPhone = false;
//       }

//       $scope.$apply();

//       $scope.updateEmail = function() {
//         $scope.message = "";
//         var new_email = $scope.new_email;
//         var new_phonenum = $scope.new_phonenum;
//         var currentUser = get_user()

//         //Make sure new e-mail is of a valid format
//         var email_regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
//         if (!email_regex.test($scope.new_email) || $scope.new_email == default_email) {
//           $scope.message = "Invalid email. Please try again.";
//           return;
//         }

//         if (new_phonenum.toString().length !== 10) {
//           return $scope.message = "Invalid phone number. Please try again!"
//         }

//         //Make sure e-mail or phone isn't already in use by another account
//         var users = snapshot.val()["Users"];
//         for (var user in users) {
//           if (users[user].firebase_id == currentUser.uid) { continue; }
//           if (users[user]["email"] == new_email) {
//             $scope.message = "This email is already taken. Please try again.";
//             return;
//           }
//           if (users[user]["phonenum"] == new_phonenum) {
//             $scope.message = "This phone number is already taken. Please try again.";
//             return;
//           }
//         }

//         var uid = get_uid();
//         var user_path = "Users/" + uid;

//        //Try fb update first
//        //On success, update db info
//         currentUser.updateEmail(new_email).then(function() {
//           firebase.database().ref(user_path).update({
//             email: new_email,
//             phonenum: new_phonenum
//           });
//           console.log("User email successfully updated");
//           window.location = $scope.hasEmail ? '/#/profile' : '/#/enter'
//         }, function(error) {
//           console.log(error);
//            $scope.message = error["message"];
//             return;
//         });

//       };

//     });

// });


// argoumichControllers.controller('EnterCtrl',
//   function ($scope, $firebaseAuth, $location) {
//     ref.once("value", function(snapshot) {
//       checkToRedirect();
//       $scope.signupsOpen = snapshot.val()["Globals"]["signupsOpen"];
//       console.log("signups open: ", $scope.signupsOpen)
//       $scope.$apply();

//       let uid = get_uid()
//       $scope.user = snapshot.val()["Users"][uid];

//       $scope.answerInstant = function(instant) {
//         firebase.database().ref('Users/' + uid).update({
//           instant: instant
//         }).then(result => {
//           $scope.hasInstant = true
//           $scope.user.instant = instant
//           $scope.$apply()
//         }).catch(err => {
//           $scope.hasInstant = false
//           $scope.$apply()
//         })
//       }

//     });
// });

// function errorMsg(errorText){
//   var newP = document.createElement("p");
//   newP.className = "error";
//   var newPText = document.createTextNode(errorText);
//   newP.appendChild(newPText); //add the text node to the newly created div.
//   console.log(newP);
//   var currentDiv = document.getElementById("errorMsg");
//   currentDiv.appendChild(newP);
// }

// function formatName(text){
//   var lowered = text.toLowerCase();
//   return lowered.charAt(0).toUpperCase() + lowered.slice(1);
// }


// function formatTime(time){
//   return [time.slice(0, 1), ":", time.slice(1,3)].join('');
// }

// argoumichControllers.controller('ProfileCtrl',
//   function ($scope, $firebaseAuth, $location, $login) {
//     ref.once("value", function(snapshot) {
//         $scope.showCancelButton = false;
//         $scope.showCancelConf = false;
//         $scope.showCancelError = false;
//         $scope.showCancelMessage = false;
//         //If signups are closed
//         $scope.signupsOpen = snapshot.val()["Globals"]["signupsOpen"];
//         console.log($scope.signupsOpen);

//         //Grab the hash here for redirect
//         var url_params = $location.search();
//         var hash = url_params['id'];

//         //if there is a hash, add an argument to the checkToRedirect function. Otherwise, dont'.
//         if (hash) {
//           var redirectUrl = "?id=" + hash
//           checkToRedirect(redirectUrl);
//         }
//         else {
//           checkToRedirect();
//         }


//         var uid = get_uid();
//         if (uid == -1) {
//           console.log("No user");
//           return;
//         }

//         var img = snapshot.val()["Users"][uid]["profpic"];
//         if(img != ""){
//           $scope.imgURL = img;
//         } else {
//           $scope.imgURL = "images/travis.jpg";
//         }

//         // guergana's stuff

//         if (hash) {
//              var uid = get_uid();
//              var email = snapshot.val()["Users"][uid]["email"];
//         //       http://stackoverflow.com/questions/1531093/how-to-get-current-date-in-javascript
//         //        http://stackoverflow.com/questions/16686640/function-to-get-yesterdays-date-in-javascript-in-format-dd-mm-yyyy
//              var today = new Date();
//              var yesterday = new Date(today);
//              yesterday.setDate(today.getDate() - 1);
//              var dd = today.getDate();
//              var mm = today.getMonth()+1; //January is 0!
//              var yyyy = today.getFullYear();
//              today = mm+'/'+dd+'/'+yyyy;
//              dd = yesterday.getDate();
//              mm = yesterday.getMonth()+1; //January is 0!
//              yyyy = yesterday.getFullYear();
//              yesterday = mm+'/'+dd+'/'+yyyy;
//              console.log(today);
//              console.log(yesterday);
//              var email1 = email + today;
//              console.log(email1);
//              var email2 = email + yesterday;
//              // hash email and compare to hash
//              var actualHash1 = CryptoJS.SHA256(email1, secret_key);
//              var actualHash2 = CryptoJS.SHA256(email2, secret_key);
//              console.log(actualHash1);
//              // if equal, set bool to True in Week1 table
//              if (actualHash1 == hash || actualHash2 == hash) {
//         //             ref.once("value", function(snapshot) {
//                 console.log("valid");

//                 // if user is here meet time won't be 000
//                 // check meet time
//                 var timeslot = snapshot.val()["Users"][uid]["timeslot"];
//                 console.log(timeslot);

//                 // if 000 then they haven't set up a date so 404
//                 if(timeslot === "000"){
//                   $scope.state = "NODATE";
//                   console.log("You don't have an Argo friend date");
//                 }

//                 else {
//                   // if not change bool setting
//                     console.log("timeslot isn't 000");
//                     console.log(uid);
//                     console.log(timeslot);
//                     ref.child('Week1').child(timeslot).child(uid).set(true);
//                     $scope.state = "CONF";
//                     $scope.showCancelButton = true;
//                     console.log("You're almost ready for your Argo friend date")
//                     //var currentUser = snapshot.val()["Users"][escapedEmail];
//                     //console.log(currentUser["firstname"])
//                     $scope.firstname = snapshot.val()["Users"][uid]["firstname"];
//                     $scope.location = snapshot.val()["Users"][uid]["location"];
//                     $scope.time = formatTime(timeslot) + " pm";

//                     setProfile();
//                 }
//              }
//              // if not equal, print out an error message? (Invalid access?)
//              else {
//                  console.log("invalid access");
//                 // show an error message on the site?
//                  window.location = "/#/error?id=2";
//                  return;
//              }
//         }
//         else {
//           var timeslot = snapshot.val()["Users"][uid]["timeslot"];

//          //if they arent' signed up for an argo date
//          //let them click the button
//           if(timeslot === "000"){
//             $scope.state = "NODATE";
//             console.log("You don't have an Argo friend date");
//           }

//          //once we give them location
//          //show location
//          else if (snapshot.val()["Users"][uid]["location"] != "TBD"){
//             $scope.state = "FRIDAY";
//             $scope.showCancelButton = true;
//             console.log("You're ready for your Argo friend date")
//          }

//           //if they signed up but haven't confirmed yet
//           //tell them to be on the lookout for the email
//           else if (snapshot.val()["Week1"][timeslot][uid] === false){
//             $scope.state = "NOCONF";
//             console.log("You need to confirm your Argo friend date") ;
//           }


//           //             they've confirmed
//           //             tell them time but not location
//           //             location: we'll let you know on friday morning
//           else if (snapshot.val()["Week1"][timeslot][uid] === true){
//             $scope.state = "CONF";
//             $scope.showCancelButton = true;
//             console.log("You're almost ready for your Argo friend date")
//           }

//           setProfile();
//         }

//         //sets the user's profile based on the state
//         /* the states are:
//           "NODATE" : The person hasn't signed up for an argo date
//           "NOCONF" : The person hasn't confirmed yet
//           "CONF"   : The person has confirmed, but doesn't have location
//           "FRIDAY" : The person has their location
//         */
//         //the state should be determined by the time this function is called
//         function setProfile() {

//              console.log($scope.state);


//              //var currentUser = snapshot.val()["Users"][escapedEmail];
//              //console.log(currentUser["firstname"])
//              $scope.firstname = snapshot.val()["Users"][uid]["firstname"];
//              $scope.location = snapshot.val()["Users"][uid]["location"];
//              $scope.time = formatTime(timeslot) + " pm";
//              //snapshot.val()["Users"][escapedEmail]["timeslot"];



//               var momentTimeslot = new moment();
//               //For Friday 4/15, we are going to disable all cancel buttons at 12:00 PM, REGARDLESS of a user's timeslot.
//               momentTimeslot.startOf("week").day("Friday").hour(12);


//               //format momentTimeslot so that it represents the user's timeslot on whatever the immediate Friday is
//               //from the current time.
//               //Also, the formula in the hour function is a janky way of converting "200" into 14, "300" into 15, etc.
//               //momentTimeslot.startOf("week").day("Friday").hour((Number(timeslot) / 100) + 12);
//               console.log("the time slot is: " + momentTimeslot.format("dddd, MMMM Do YYYY, h:mm:ss a"));


//               //determine whether the cancel button should have an enabled or disabled style.
//               //also determines whether or not to show the cancel error
//               $scope.cancelStyle = function() {
//                 if (moment().isAfter(momentTimeslot, 'minute')) {
//                 //if (momentTimeslot.diff(moment(), 'minutes') <= 30) {
//                   $scope.showCancelError = true;
//                   return "cancelDisable button";
//                 }
//                 return "button";
//               }

//               $scope.confirmCancel = function() {
//                 if (moment().isAfter(momentTimeslot, 'minute')) {
//                 //if (momentTimeslot.diff(moment(), 'minutes') <= 30) {
//                   //user can't confirm because the cancel button should be disabled
//                   return;
//                 }
//                 $scope.showCancelButton = false;
//                 //show the cancel confirmation buttons
//                 $scope.showCancelConf = true;
//              }

//              $scope.cancel = function(result) {
//                 //user cancelled the date
//                 if (result) {
//                     ref.child('Users').child(uid).child("timeslot").set("000", function(error) {
//                         if (error) {
//                             console.log("error in cancelling");
//                         }
//                         else {
//                             $scope.$apply(function() {
//                                 console.log("date is cancelled");
//                                 $scope.showCancelConf = false;
//                                 $scope.showCancelMessage = true;
//                                 // guergana added this
// //                                $scope.state = "NODATE";

//                                 //Remove the user from the Week1 table. Between this and changing
//                                 //the user's time back to "000", $scope.state will effectively be "NODATE" on refresh
//                                 ref.child('Week1').child(timeslot).child(uid).remove();
//                             });
//                         }
//                     });
//                 }

//                 //user decided not to cancel the date
//                 else {
//                     console.log("date not cancelled");
//                     $scope.showCancelConf = false;
//                     $scope.showCancelButton = true;
//                 }
//              }
//         }
//     //hacky, but i don't know how else to render the HTML with all the valid scope arguments instead
//     //of them being undefined :-\
//     $scope.$apply();
//     })
// });

// argoumichControllers.controller('ErrorCtrl', function ($scope, $compile, $location) {
//   var url_params = $location.search();
//   var errorMsgId = url_params['id'];
//   if (errorMsgId == 1) {
//     var errorMsg = "Error: You haven't signed up for a meeting!";
//     var errorText = document.getElementById("error");
//     errorText.innerHTML = errorMsg;
//     $compile(errorText);
//   } else if (errorMsgId == 2) {
//     var errorMsg = "Error: Invalid Access";
//     var errorText = document.getElementById("error");
//     errorText.innerHTML = errorMsg;
//     $compile(errorText);
//   }
// });



// argoumichControllers.controller('AvailCtrl',
//   function ($scope) {
//     ref.once("value", function(snapshot) {
//     //email
//     checkToRedirect();
//     console.log("someone logged in")
//     var uid = get_uid();

//     //signups are closed
//     var signupsOpen = snapshot.val()["Globals"]["signupsOpen"];
//     var userTime = snapshot.val()["Users"][uid]["timeslot"]
//     if(userTime != "000" || !signupsOpen){
//       //redirect
//       window.location = "/#/profile"
//       console.log("you can't pick a time :/")
//     }
//   })

//   $scope.updateAvailTimes = function () {
//     event.preventDefault()
//     //email
//     if(!firebase.auth().currentUser){
//       console.log("no one logged in")
//       return;
//     }
//     console.log("someone logged in");
//     var uid = get_uid();

//     //if they already have a time, don't let them submit
//     ref.once("value", function(snapshot) {
//     var userTime = snapshot.val()["Users"][uid]["timeslot"]
//     console.log($scope.choice)
//     if(userTime === "000"){
//       var list = {};
//       //console.log(times)
//       console.log("Chosen time:" + $scope.choice)
//       var listString = "Week1/" + $scope.choice + "/" + uid
//       console.log(listString)
//       list[listString] = false;
//       ref.child('Users').child(uid).child("timeslot").set($scope.choice);

//       ref.update(list);

//       window.location = "/#/confirmation"
//     } else {
//       //they shouldn't ever get here
//       console.log(uid, "has already picked time", userTime);
//     }
//   })

//   }
// });

// argoumichControllers.controller('UnavailCtrl', function ($scope) {

//   $scope.reset = function() {
//     $scope.availability = {
//      'Monday': [false, false, false],
//      'Tuesday': [false, false, false],
//      'Wednesday': [false, false, false],
//      'Thursday': [false, false, false],
//      'Friday': [false, false, false],
//      'Saturday': [false, false, false],
//      'Sunday': [false, false, false]
//    }
//   }

//   // init $scope.availability
//   $scope.reset();

//   $scope.submit = function() {
//     // return console.log($scope);
//     firebase.database().ref('Users/' + get_uid()).update({
//       availability: $scope.availability
//     }).then(result => {
//       $scope.submitted = true
//       $scope.$apply()
//     }).catch(err => {
//       $scope.submitted = true
//       $scope.$apply()
//     })
//   }


// });
