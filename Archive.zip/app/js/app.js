'use strict';

/* App Module */

var app = angular.module('493FinalProj', [
  'ngRoute',
  'Final_Controllers'
]);


app.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
      when('/', {
        templateUrl: 'partials/homepage.html',
        controller: 'searchPage'
      }).
      when('/mytrips', {
        templateUrl: 'partials/mytrips.html',
        controller: 'searchPage'
      }).
      when('/addtrip', {
        templateUrl: 'partials/addtrip.html'
      }).
      otherwise({
        redirectTo: '/404'
      });
  }]);
